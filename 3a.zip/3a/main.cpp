#include <iostream>

using namespace std;

int main()
{
   int x;
   cout<<"Ingrese un valor "<<endl;
   cin>>x;
   x = (x*3600/1000);

   cout<<"El resultando de la conversion es "<<x<<"kms/hr"<<endl;

    return 0;
}
