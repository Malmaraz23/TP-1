#include <iostream>
#include <math.h>

using namespace std;

int main()
{
    float a;
    float b;
    float c;
    float D1;
    float D2;
    float R1;
    float R2;
    float x;
    cout<<"Ingrese el valor numerico de a "<<endl;
    cin>>a;
    cout<<"Ingrese el valor numerico de b "<<endl;
    cin>>b;
    cout<<"Ingrese el valor numerico de c "<<endl;
    cin>>c;

    x = b*b-4*a*c;

    if(x>0 && a!=0)
    {
        D1 = (- b + sqrt( pow(b,2) - 4*a*c)) / (2*a) ;
        D2 = (- b - sqrt( pow(b,2) - 4*a*c)) / (2*a) ;
        cout<<"Hay 2 raices reales y distintas "<<"X1="<<D1<<" y "<<"X2="<<D2<<endl;
    }
        else if (x==0)
        {
            R1 = (- b + sqrt( pow(b,2) - 4*a*c)) / (2*a);
            R2 = (- b - sqrt( pow(b,2) - 4*a*c)) / (2*a);

            cout<<"Hay 2 raices iguales "<<"X1="<<R1<<" y "<<"X2="<<R2<<endl;
        }
        else
        {

            cout<<"No existen raices reales "<<endl;


        }

    return 0;
}
